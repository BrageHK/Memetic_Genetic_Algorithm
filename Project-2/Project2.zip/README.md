# Project 2
## Run project
Make sure you have rust installed. Run with:
```zsh
cargo run --release
```